import React, { useState } from 'react';
import './RegisterPage.css';

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleRegister = (e) => {
    e.preventDefault();
    // Conecte aqui ao backend para cadastrar o usuário
    // Exemplo: fetch('/api/register', { method: 'POST', body: JSON.stringify({ email, password }) })
  };

  return (
    <div className="register-page">
      <div className="register-form-container">
        <h2 className="register-title">Crie sua conta</h2>
        <form onSubmit={handleRegister} className="register-form">
          <div className="form-group">
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              placeholder="Seu email" 
              required 
              className="register-input" 
            />
          </div>
          <div className="form-group">
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              placeholder="Sua senha" 
              required 
              className="register-input" 
            />
          </div>
          <div className="form-group">
            <input 
              type="password" 
              value={confirmPassword} 
              onChange={(e) => setConfirmPassword(e.target.value)} 
              placeholder="Confirme sua senha" 
              required 
              className="register-input" 
            />
          </div>
          <button type="submit" className="register-btn">Registrar-se</button>
        </form>
        <p className="login-link">Já tem uma conta? <a href="/login">Entrar</a></p>
      </div>
    </div>
  );
};

export default RegisterPage;
