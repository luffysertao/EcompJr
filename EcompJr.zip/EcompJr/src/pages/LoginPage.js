import React, { useState } from 'react';
import './LoginPage.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Conecte aqui ao backend para validar o login
    // Exemplo: fetch('/api/login', { method: 'POST', body: JSON.stringify({ email, password }) })
  };

  return (
    <div className="login-page">
      <div className="login-form-container">
        <h2 className="login-title">Bem-vindo de volta!</h2>
        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              placeholder="Seu email" 
              required 
              className="login-input" 
            />
          </div>
          <div className="form-group">
            <input 
              type="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              placeholder="Sua senha" 
              required 
              className="login-input" 
            />
          </div>
          <button type="submit" className="login-btn">Entrar</button>
        </form>
        <p className="signup-link">Não tem uma conta? <a href="/register">Cadastre-se</a></p>
      </div>
    </div>
  );
};

export default LoginPage;
