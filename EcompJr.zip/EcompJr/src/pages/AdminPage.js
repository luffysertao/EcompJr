import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Importa o hook useNavigate para navegação
import './AdminPage.css';
import logo from '../assets/logo.png'; // Importa a logo

const AdminPage = () => {
  // Estados para armazenar dados
  const [users, setUsers] = useState([]);
  const [tasks, setTasks] = useState([]);

  const navigate = useNavigate(); // Hook para navegação

  // Efeito para buscar dados do backend ao carregar a página
  useEffect(() => {
    // TODO: Buscar dados do back-end
    // Exemplos:
    // fetch('/api/users') para buscar usuários
    // fetch('/api/tasks') para buscar tarefas

    // Simulação de dados - substituir com dados reais do back-end
    setUsers([
      { id: 1, name: 'Felipe Amorim', email: 'felipedocarmo05@gmail.com' },
      { id: 2, name: 'Tamilly Costa', email: 'tamillycosta899@gmail.com' }
    ]);
    setTasks([
      { id: 1, title: 'Concluir Projeto X', status: 'Em andamento' },
      { id: 2, title: 'Revisar Documentação', status: 'Pendente' }
    ]);
  }, []);

  // Função para redirecionar para a página inicial
  const handleLogoClick = () => {
    navigate('/');
  };

  return (
    <div className="admin-page">
      {/* Botão de logo no canto superior direito */}
      <div className="logo-container">
        <img src={logo} alt="Ecomp Jr Logo" className="logo" onClick={handleLogoClick} />
      </div>

      {/* Barra lateral de navegação */}
      <aside className="sidebar">
        <h2>Admin</h2>
        <nav>
          <ul>
            <li><a href="#dashboard">Dashboard</a></li>
            <li><a href="#users">Usuários</a></li>
            <li><a href="#tasks">Tarefas</a></li>
          </ul>
        </nav>
      </aside>

      {/* Conteúdo principal */}
      <main className="main-content">
        {/* Seção Dashboard */}
        <section id="dashboard" className="dashboard-section">
          <h2>Dashboard</h2>
          <p>Visão geral das atividades e estatísticas da plataforma.</p>
          {/* TODO: Adicionar widgets de estatísticas como contadores de usuários, tarefas, etc. */}
        </section>

        {/* Seção Usuários */}
        <section id="users" className="users-section">
          <h2>Gerenciar Usuários</h2>
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nome</th>
                  <th>Email</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>
                      {/* Botões de ação - conectar com o back-end */}
                      <button className="edit-button">Editar</button>
                      <button className="delete-button">Excluir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Seção Tarefas */}
        <section id="tasks" className="tasks-section">
          <h2>Gerenciar Tarefas</h2>
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Título</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map(task => (
                  <tr key={task.id}>
                    <td>{task.id}</td>
                    <td>{task.title}</td>
                    <td>{task.status}</td>
                    <td>
                      {/* Botões de ação - conectar com o back-end */}
                      <button className="edit-button">Editar</button>
                      <button className="delete-button">Excluir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

export default AdminPage;
