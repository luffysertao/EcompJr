import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      {/* Adicione componentes e lógica para gerenciamento de usuários aqui */}
    </div>
  );
};

export default AdminDashboard;
